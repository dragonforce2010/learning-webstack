'use strict';

var cat = {
    name: 'Fluffy', 
    color: 'White'
}

display(Object.getOwnPropertyDescriptor(cat, 'name'))